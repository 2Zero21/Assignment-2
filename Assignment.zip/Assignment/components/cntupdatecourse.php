<?php
	/*
	 Codebase : Student Registration System
	 Component Model : Fetch Course details
	 Author : Aravind G
	 Date : 18-06-2021
	 Stack : Adv. PHP, Mysql, Etc.
	*/
	
	
	include '../dbconn/dbconn.php';
	
	$DB_DATABASE = "nativeramdb";
	$objdb = new dbconn;
	$conn = $objdb->setDBConn();
	mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


	
	/*
		update course dtls
	*/
	if (isset($_REQUEST) AND $_REQUEST['cID'] != "" AND $_REQUEST['type'] == 'edit') 
	{
		$getSQL = "select cname,cdtls from tblcoursedtls where cid=".$_REQUEST['cID'];
		//echo $getSQL;exit;
		$res = mysqli_query($conn,$getSQL);
		
		if($res){
			while($coursedata = mysqli_fetch_array($res)){ 
				//print_r($coursedata);
				$data = $_REQUEST['cID'].",".$coursedata['cname'].",".$coursedata['cdtls'];
				echo $data;
			}
		}
		//echo $data;
	}
	
	//dbconn close...
	$objdb->CloseDBConn($conn);
	
?>