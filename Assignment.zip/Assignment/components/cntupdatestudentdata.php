<?php
	/*
	 Codebase : Student Registration System
	 Component Model : Update Student details
	 Author : Aravind G
	 Date : 18-06-2021
	 Stack : Adv. PHP, Mysql, Etc.
	*/
	
	
	include '../dbconn/dbconn.php';
	
	$DB_DATABASE = "nativeramdb";
	$objdb = new dbconn;
	$conn = $objdb->setDBConn();
	mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


	
	/*
		UPDATE STUDENT DETAILS
	*/
	if (isset($_REQUEST) AND $_REQUEST['stdID'] != "" AND $_REQUEST['type'] == 'newupdate') 
	{
		$updatesql = "update tblstudentdtls set stdFname='".$_REQUEST['fname']."',stdLname='".$_REQUEST['lname']."',stdContactNo='".$_REQUEST['cno']."',stddob=STR_TO_DATE('".$_REQUEST['dob']."','%Y-%m-%d') where stdid=".$_REQUEST['stdID'];
		//echo $updatesql;exit;
		$res = mysqli_query($conn,$updatesql);
		if($res){
			print_r($res);
		}
	}
	
	//dbconn close...
	$objdb->CloseDBConn($conn);
	
?>