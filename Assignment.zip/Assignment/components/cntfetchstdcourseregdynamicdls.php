<?php
/*
	Codebase : Student Registration System
	Component Model : Insert Student details
	Author : Aravind G
	Date : 18-06-2021
	Stack : Adv. PHP, Mysql, Etc.
*/
	
	
include '../dbconn/dbconn.php';
	
$DB_DATABASE = "nativeramdb";
$objdb = new dbconn;
$conn = $objdb->setDBConn();
mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());

class studentreg{

	// Constructor
	public function __construct(){
		#echo 'The class "' . __CLASS__ . '" was initiated!<br>';
	}

	public function getstudentdtls($conn){
		#Execute the query (the recordset $res contains the result)
		$strSQL = "SELECT * FROM tblstudentdtls";
		$resrowstd = mysqli_query($conn,$strSQL);
		$strdata = '';
		while($resstudents = mysqli_fetch_array($resrowstd)){ 
			$strdata = $strdata .'#####'.$resstudents['stdid'].'---'.$resstudents['stdFname'];
		}
		return $strdata;
	}

	public function getcoursedtls($conn){
	
		#Execute the query (the recordset $res contains the result)
		$strSQL = "SELECT * FROM tblcoursedtls";
		$resrowcus = mysqli_query($conn,$strSQL);
		$cstrdata = '';
		while($courserow = mysqli_fetch_array($resrowcus)){ 
			$cstrdata = $cstrdata .'XXXXX'.$courserow['cid'].'==='.$courserow['cname'];
		}
		return $cstrdata;
	}

	public function getData($conn){

		$resrowcus = $this->getcoursedtls($conn);
		$resrowstd = $this->getstudentdtls($conn);
		$resultdata =$resrowstd."V=====V".$resrowcus;
		echo $resultdata;
	}

}

$objstdregdtls = new studentreg;
$objstdregdtls->getData($conn);

//dbconn close...
#$objdb->CloseDBConn($conn);
?>