<?php
	/*
	 Codebase : Student Registration System
	 Component Model : Insert Course details
	 Author : Aravind G
	 Date : 18-06-2021
	 Stack : Adv. PHP, Mysql, Etc.
	*/
	
	include '../dbconn/dbconn.php';
	
	$DB_DATABASE = "nativeramdb";
	$objdb = new dbconn;
	$conn = $objdb->setDBConn();
	mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());

	/*
		INSERT STUDENT DETAILS
	*/
	if (isset($_REQUEST)) {
		$values = "'".$_REQUEST['cid']."','".$_REQUEST['cdtls']."',current_timestamp()";
		$inscoursedtlsstrSQL = "insert into tblcoursedtls(cname,cdtls,cstartDate) values($values)";
		#echo $inscoursedtlsstrSQL;exit;
		$res = mysqli_query($conn,$inscoursedtlsstrSQL);
		if($res){
			print_r($res);
		}

	}

	//dbconn close...
	$objdb->CloseDBConn($conn);
	
?>