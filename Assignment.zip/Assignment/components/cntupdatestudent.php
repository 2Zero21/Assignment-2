<?php
	/*
	 Codebase : Student Registration System
	 Component Model : Fetch Student details
	 Author : Aravind G
	 Date : 18-06-2021
	 Stack : Adv. PHP, Mysql, Etc.
	*/
	
	
	include '../dbconn/dbconn.php';
	
	$DB_DATABASE = "nativeramdb";
	$objdb = new dbconn;
	$conn = $objdb->setDBConn();
	mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


	
	/*
		UPDATE STUDENT DETAILS
	*/
	if (isset($_REQUEST) AND $_REQUEST['stdID'] != "" AND $_REQUEST['type'] == 'edit') 
	{
		$getSQL = "select stdFname,stdLname,stdContactNo,stddob,stdstatus,stdJoinDate from tblstudentdtls where stdid=".$_REQUEST['stdID'];
		//echo $getSQL;exit;
		$res = mysqli_query($conn,$getSQL);
		
		if($res){
			while($studentdata = mysqli_fetch_array($res)){ 
				//print_r($studentdata);
				$data = $_REQUEST['stdID'].",".$studentdata['stdFname'].",".$studentdata['stdLname'].",".$studentdata['stdContactNo'].",".$studentdata['stddob'].",".$studentdata['stdstatus'].",".$studentdata['stdJoinDate'];
				echo $data;
			}
		}
		//echo $data;
	}
	
	//dbconn close...
	$objdb->CloseDBConn($conn);
	
?>