<?php
/*
	Codebase : Student Registration System
	Component Model : Insert Student details
	Author : Aravind G
	Date : 18-06-2021
	Stack : Adv. PHP, Mysql, Etc.
*/
	
	
include 'dbconn/dbconn.php';
	
$DB_DATABASE = "nativeramdb";
$objdb = new dbconn;
$conn = $objdb->setDBConn();
mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


#Execute the query (the recordset $res contains the result)

$strSQL = "SELECT * FROM tblstudentdtls";
$res = mysqli_query($conn,$strSQL);



//dbconn close...
$objdb->CloseDBConn($conn);
?>