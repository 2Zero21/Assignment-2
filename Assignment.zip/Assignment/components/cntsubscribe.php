<?php
	/*
	 Codebase : Student Registration System
	 Component Model : Insert Student Course Registration details
	 Author : Aravind G
	 Date : 18-06-2021
	 Stack : Adv. PHP, Mysql, Etc.
	*/
	
	
	include '../dbconn/dbconn.php';
	
	$DB_DATABASE = "nativeramdb";
	$objdb = new dbconn;
	$conn = $objdb->setDBConn();
	mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


	/*
		INSERT STUDENT DETAILS
	*/
	if (isset($_REQUEST)) {
		// Array ( [cno] => xxxxx [dt] => 06/16/2021 [lname] => xxxxx [fname] => xxxxx )
		$values = "'".$_REQUEST['fname']."','".$_REQUEST['lname']."','".$_REQUEST['cno']."',STR_TO_DATE('".$_REQUEST['dt']."','%m/%d/%Y'),1,current_timestamp()";
		$insstudentdtlsstrSQL = "insert into tblsubscribecoursedtls(stdFname,stdLname,stdContactNo,stddob,stdstatus,stdJoinDate) values($values)";
		#echo $insstudentdtlsstrSQL;exit;
		$res = mysqli_query($conn,$insstudentdtlsstrSQL);
		if($res){
			print_r($res);
		}
	}

	//dbconn close...
	$objdb->CloseDBConn($conn);
	
?>