<?php
/*
	Codebase : Student Registration System
	Component Model : Insert Student details
	Author : Aravind G
	Date : 18-06-2021
	Stack : Adv. PHP, Mysql, Etc.
*/
	
	
include 'dbconn/dbconn.php';
	
$DB_DATABASE = "nativeramdb";
$objdb = new dbconn;
$conn = $objdb->setDBConn();
mysqli_select_db($conn,$DB_DATABASE) or die(mysqli_error()) or die(mysqli_error());


function getstudentdtls($conn){
	#Execute the query (the recordset $res contains the result)
	$strSQL = "SELECT * FROM tblstudentdtls";
	$resrowstd = mysqli_query($conn,$strSQL);
	/*while($resstudents = mysqli_fetch_array($resrowstd)){ 
		#print_r($resstudents);
	}*/
	return $resrowstd;
}

function getcoursedtls($conn){
	#Execute the query (the recordset $res contains the result)
	$strSQL = "SELECT * FROM tblcoursedtls";
	$resrowcus = mysqli_query($conn,$strSQL);
	/*while($courserow = mysqli_fetch_array($resrowcus)){ 
		#print_r($courserow);
	}*/
	return $resrowcus;
}


function getstdcourseregdtls($conn){
	#Execute the query (the recordset $res contains the result)
	$strSQL = "
			SELECT 
				t2.subid AS subid,
				t1.stdFname AS stdFname,
				t3.cname AS cname
			FROM
				tblstudentdtls t1
					LEFT JOIN
				tblsubscribecoursedtls t2 ON (t1.stdid = t2.stdid)
					LEFT JOIN
				tblcoursedtls t3 ON (t3.cid = t2.cid)
			WHERE
				t1.stdid IS NOT NULL
					AND t3.cid IS NOT NULL";
	//echo $strSQL; exit;
	$regdtls = mysqli_query($conn,$strSQL);
	return $regdtls;
}
//dbconn close...
#$objdb->CloseDBConn($conn);
?>