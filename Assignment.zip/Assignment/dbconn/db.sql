/*
Date: 19-06-2021 
DB: student Registration Course DB SQL.
Subject: Assignment#2
*/


/*
STUDENT Details SQL
*/

create table tblstudentdtls(
stdid int(11) NOT NULL AUTO_INCREMENT,
stdFname varchar(50) COLLATE utf8_unicode_ci NOT NULL, 
stdLname varchar(50) COLLATE utf8_unicode_ci NOT NULL, 
stdContactNo varchar(255) COLLATE utf8_unicode_ci NOT NULL, 
stdJoinDate datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
stdstatus bool,
 PRIMARY KEY (stdid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


/*
COURSE Details SQL
*/

create table tblcoursedtls(
cid int(11) NOT NULL AUTO_INCREMENT,
cname varchar(50) COLLATE utf8_unicode_ci NOT NULL, 
cdtls varchar(2000) COLLATE utf8_unicode_ci NOT NULL, 
cstartDate datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (cid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


/*
STUDENT Course Subscribe SQL
*/

create table tblsubscribecoursedtls(
subid int(11) NOT NULL AUTO_INCREMENT,
stdid int(11),
cid int(11),
subscribeDate datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (subid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


/*
	 Fetch sql query for subscribe student course dtls
*/
SELECT 
    t2.subid AS subid,
    t1.stdFname AS stdFname,
    t3.cname AS cname
FROM
    tblstudentdtls t1
        LEFT JOIN
    tblsubscribecoursedtls t2 ON (t1.stdid = t2.stdid)
        LEFT JOIN
    tblcoursedtls t3 ON (t3.cid = t2.cid)
WHERE
    t1.stdid IS NOT NULL
        AND t3.cid IS NOT NULL;