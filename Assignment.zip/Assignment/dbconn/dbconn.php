<?php

class dbconn{

	// Constructor
    public function __construct(){
        #echo 'The class "' . __CLASS__ . '" was initiated!<br>';
    }

	public function setDBConn(){

		$DB_HOST= "localhost";
		$DB_USER = "root";
		$DB_PASSWORD = "pass12345";
	

		// Create connection
		$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASSWORD) or die("Connect failed: %s\n". $conn -> error);

		// Check connection
		if (!$conn) {
		echo "mysql_connection_fail check the logs and update accordingly ... !";
		die("Connection failed: " . mysqli_connect_error());
		
		$conn=NULL;
		return $conn;

		}else{

		return $conn;
		}
	}

	public function CloseDBConn($conn){
		mysqli_close($conn);
	}  
}
?>