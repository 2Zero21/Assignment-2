<?php
/*
	Codebase : Student Registration System
	Component Model : Insert Student details
	Author : Aravind G
	Date : 18-06-2021
	Stack : Adv. PHP, Mysql, Etc.
*/
	
require_once 'components/cntfetchstudentdtls.php';

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Student Course Registration System:</title>

    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
	
	<!-- bootstrap datepicker -->
    <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="dist/alert.css">
    <link rel="stylesheet" href="dist/css/system.css">

    <link rel="stylesheet" href="dist/css/skins/skin-blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- Main Header -->
        <header class="main-header">

            <!-- Logo -->
            <a href="#" class="logo">
                <!-- mini logo for sidebar mini 50x50 pixels -->
                <span class="logo-mini"><b>S</b>CR</span>
                <!-- logo for regular state and mobile devices -->
                <span class="logo-lg"><b>Student-Course </b>Reg.</span>
            </a>

            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>
                <!-- Navbar Right Menu -->
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                    </ul>
                </div>
            </nav>
        </header>
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">

            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">

                <!-- Sidebar Menu -->
                <ul class="sidebar-menu" data-widget="tree">
                    <li class="header">System Menu</li>
                    <!-- Optionally, you can add icons to the links -->
                    <li><a href="student.html"><i class="fa fa-user"></i> <span>Add Student </span></a></li>
                    <li><a href="course.html"><i class="fa fa-book"></i> <span>Add Course</span></a></li>
                    <li><a href="subscribe.php"><i class="fa fa-id-badge"></i> <span>Subscribe</span></a></li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-search"></i> <span>Reports</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu active">
                            <li><a href="ssearch.php">Search Student</a></li>
                            <li><a href="scourse.php">Search Course</a></li>
                            <li><a href="ssubscribe.php">Student Course Registration</a></li>
                        </ul>
                    </li>
                </ul>
                <!-- /.sidebar-menu -->
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h6 style="color:#ccc">
                    Student Course Registration System:
                    <small></small>
                </h6>
            </section>
            <!-- Main content -->
            <section class="content container-fluid">
                <div class="row content">
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title">Students Report :</h3>
                            <div class="box-tools pull-right">
                            </div><!-- /.box-tools -->
                        </div><!-- /.box-header -->
                        <div class="box-body">
                            <!-- /.card-header -->
                            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                                <div class="col-sm-12">
                                    <table id="ssearchID" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                                        <thead>
                                            <tr role="row">
                                                <th class="sorting" tabindex="0" aria-controls="ssearchID" rowspan="1" colspan="1" style="width: 40%;">First Name</th>
                                                <th class="sorting" tabindex="1" aria-controls="ssearchID" rowspan="1" colspan="1" style="width: 45%;">Last Name</th>
                                                <th class="sorting" tabindex="2" aria-controls="ssearchID" rowspan="1" colspan="1" style="width: 15%;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbodyDataID">
                                        <?php
                                            $str = "";
                                            while($studentdata = mysqli_fetch_array($res)){ 
                                            if($studentdata['stdid'] %2 ==0){
                                                $str = "<tr role='row' class='even'>";
                                            }else{
                                                $str = "<tr role='row' class='odd'>";
                                            }
											$str = $str. '<td class="sorting_1">'.$studentdata['stdFname'].'</td>';                                            
                                            $str = $str. '<td class="sorting_1">'.$studentdata['stdLname'].'</td>';                                           
	                                        #print_r($studentdata['stdid']."||".$studentdata['stdFname']."||".$studentdata['stdLname']."||".$studentdata['stdContactNo']."||".$studentdata['stddob']."||".$studentdata['stdstatus']."<br/>");
                                            $str = $str. "<td><a data-toggle=\"modal\" data-target=\"#modal-std-edit\" data-custom=".$studentdata['stdid']." class=\"editID\"><i class=\"fa fa-edit\"></i> <span>Edit</span><span style='display:none;'>".$studentdata['stdid']."</span></a> /
                                                    <a data-toggle=\"modal\" data-target=\"#modal-std-delete\" style=\"color:red\" class=\"deleteID\"><i class=\"fa fa-trash\"></i> <span>Delete</span><span style='display:none;'>".$studentdata['stdid']."</span></a>
                                                </td></tr>";
											echo $str;
                                        }
                                        ?>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
												<th rowspan="1" colspan="1">First Name</th>
                                                <th rowspan="1" colspan="1">Last Name</th>
                                                <th rowspan="1" colspan="1">Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <div class="row">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
     
    <div class="modal fade" id="modal-std-edit" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Edit Student Details:</h4>
                </div>
                <div class="modal-body">
                    <form action="#" method="post">
                        <div class="card-body"> 
                            <div class="form-group"> 
								<input type="hidden" id="estdID"/>
                                <label for="Fname">First Name:</label>
                                <input type="text" class="form-control" id="eddmdlfnameid" placeholder="Enter First Name">
                            </div>
                            <div class="form-group">
                                <label for="Lname">Last Name:</label>
                                <input type="text" class="form-control" id="eddmdllnameid" placeholder="Enter Last Name">
                            </div>
                            <!--
							<div class="form-group">
                                <label for="dob">DOB:</label>
                                <input type="text" class="form-control" id="eddmdldobid" placeholder="Enter Date Of Birth">
                            </div>
							-->
							<div class="input-group date">
								<div class="input-group-addon">
									<i class="fa fa-calendar"></i>
								</div>
								<input type="text" class="form-control pull-right" id="datepicker" placeholder="Enter Date Of Birth (Ex:mm/dd/YYYY)">
							</div>
                            <div class="form-group">
                                <label for="Cno">Contact No.:</label>
                                <input type="text" class="form-control" id="eddmdlcnoid" placeholder="Enter Contact No">
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal" id="mdleditstddataID">Save and Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modal-std-delete" style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Delete Student Details:</h4>
                </div>
                <div class="modal-body">
                    <form action="#" method="post">
                        <div class="card-body"> 
                            <div class="form-group"> 
								<input type="hidden" id="delstdID"/>
                                <label for="Fname">First Name:</label>
                                <input type="text" class="form-control" id="dmdlfnameid" placeholder="Enter First Name" readonly>
                            </div>
                            <div class="form-group">
                                <label for="Lname">Last Name:</label>
                                <input type="text" class="form-control" id="dmdllnameid" placeholder="Enter Last Name" readonly>
                            </div>
                            <div class="form-group">
                                <label for="dob">DOB:</label>
                                <input type="text" class="form-control" id="dmdldobid" placeholder="Enter Date Of Birth" readonly>
                            </div>

                            <div class="form-group">
                                <label for="Cno">Contact No.:</label>
                                <input type="text" class="form-control" id="dmdlcnoid" placeholder="Enter Contact No" readonly>
                            </div>

                        </div>
                        <!-- /.card-body -->
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal" id="mdldeletestddataID">Delete and Close</button>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
    </section>
 </div>
    <!-- /.content-wrapper -->
    <!-- Main Footer -->
    <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
            version : 1.0.0
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2021 <a href="#">Student Information System.</a></strong> All rights reserved.
    </footer>


    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
    immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->
    <!-- REQUIRED JS SCRIPTS -->
    <!-- jQuery 3 -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
	<script src="dist/alert.js"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
	
    <!-- bootstrap datepicker -->
    <script src="bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
	
    <!-- DataTables -->
    <script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/system.js"></script>
    <!-- page script -->
    <script>
		//Date picker
        $('#datepicker').datepicker({
            dateFormat: 'yy-mm-dd',
			autoclose: true,
			
        });

        $(function () {
            $('#ssearchID').DataTable()
        })
    </script>
	
	<script>
	try{  

		$(document).ready(function() {
			console.log("========0");
			$('.editID').click(function(event){
				console.log("========1");
				//var dynastr = this; 
				//console.log($(this).children()[2].innerHTML);
				//alert(JSON.stringify($(this).children()[2].innerHTML));
				//console.log($(this).children()[2])
				$.ajax({
						type: "POST",
						url: "http://localhost/final/components/cntupdatestudent.php?type=edit&stdID="+$(this).children()[2].innerHTML,
					}).done(function (data) {
						arrdata = data.split(",");
						if(arrdata.length){
							//dmdlfnameid dmdllnameid dmdldobid dmdlcnoid estdID
							$('#estdID').val(arrdata[0]);
							$('#eddmdlfnameid').val(arrdata[1]);
							$('#eddmdllnameid').val(arrdata[2]);
							$('#datepicker').val(arrdata[4]);
							$('#eddmdlcnoid').val(arrdata[3]);
							console.log("stddata found:", arrdata);
						}
						
					});
			});
			
			$('.deleteID').click(function(event){
				console.log("========1");
				//var dynastr = this; 
				//console.log($(this).children()[2].innerHTML);
				//alert(JSON.stringify($(this).children()[2].innerHTML));
				//console.log($(this).children()[2])
				$.ajax({
						type: "POST",
						url: "http://localhost/final/components/cntupdatestudent.php?type=edit&stdID="+$(this).children()[2].innerHTML,
					}).done(function (data) {
						arrdata = data.split(",");
						if(arrdata.length){
							//alert(arrdata[4])
							//delstdID dmdlfnameid dmdllnameid dmdldobid dmdlcnoid
							$('#delstdID').val(arrdata[0]);
							$('#dmdlfnameid').val(arrdata[1]);
							$('#dmdllnameid').val(arrdata[2]);
							$('#dmdldobid').val(arrdata[4]);
							$('#dmdlcnoid').val(arrdata[3]);
							console.log("stddata found:", arrdata);
						}
						
					});
			});
			
			
			/*
			 EDIT MODEL TO UPDATE STUDENT DTLS...
			*/
			$('#mdleditstddataID').on('click',function(event){
				console.log("========mdl1");
				if($('#estdID').val() !=""){
					url = "http://localhost/final/components/cntupdatestudentdata.php?type=newupdate&"+
						"fname="+$('#eddmdlfnameid').val()+"&"+
						"lname="+$('#eddmdllnameid').val()+"&"+
						"dob="+$('#datepicker').val()+"&"+
						"cno="+$('#eddmdlcnoid').val()+"&"+
						"stdID="+$('#estdID').val();
					console.log("========mdl1", url);
					$.ajax({
						type: "POST",
						url: url
					}).done(function (data) {
						//dmdlfnameid dmdllnameid dmdldobid dmdlcnoid estdID
						if(data == 1){
							swal("success!", "one student record updated successfully...!", "success");
								window.setTimeout(() => {
										location.href = "http://localhost/final/ssearch.php";
								}, 2000);
						}
						console.log("stddata found:", data);
					});
					
				}
				
			});
			
			/*
			 DELETE MODEL TO UPDATE STUDENT DTLS...
			*/
			$('#mdldeletestddataID').on('click',function(event){
				console.log("========mdl2");
				if($('#delstdID').val() !=""){
					url = "http://localhost/final/components/cntdeletestudent.php?type=del&"+
						"stdID="+$('#delstdID').val();
					console.log("========mdl2", url);
					$.ajax({
						type: "POST",
						url: url
					}).done(function (data) {
						//dmdlfnameid dmdllnameid dmdldobid dmdlcnoid estdID
						if(data == 1){
							swal("success!", "one record deleted successfully...!", "success");
								window.setTimeout(() => {
										location.href = "http://localhost/final/ssearch.php";
								}, 2000);
						}
						console.log("stddata found:", data);
					});
					
				}
				
			});
			
		});
	
}catch(e){  
	alert("Error:::"+e.message); 
	location.href = "http://localhost/final/index.html";
}  
</script>
</body>
</html>