<?php
/*
	Codebase : Student Registration System
	Component Model : Insert Student details
	Author : Aravind G
	Date : 18-06-2021
	Stack : Adv. PHP, Mysql, Etc.
*/
	
require_once 'components/cntfetchstdcourseregdls.php';
$regdtls = getstdcourseregdtls($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Student Course Registration System:</title>

    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/system.css">

    <link rel="stylesheet" href="dist/css/skins/skin-blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- Main Header -->
        <header class="main-header">

            <!-- Logo -->
            <a href="#" class="logo">
                <!-- mini logo for sidebar mini 50x50 pixels -->
                <span class="logo-mini"><b>S</b>CR</span>
                <!-- logo for regular state and mobile devices -->
                <span class="logo-lg"><b>Student-Course </b>Reg.</span>
            </a>

            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>
                <!-- Navbar Right Menu -->
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                    </ul>
                </div>
            </nav>
        </header>
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">

            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">

                <!-- Sidebar Menu -->
                <ul class="sidebar-menu" data-widget="tree">
                    <li class="header">System Menu</li>
                    <!-- Optionally, you can add icons to the links -->
                    <li><a href="student.html"><i class="fa fa-user"></i> <span>Add Student </span></a></li>
                    <li><a href="course.html"><i class="fa fa-book"></i> <span>Add Course</span></a></li>
                    <li><a href="subscribe.php"><i class="fa fa-id-badge"></i> <span>Subscribe</span></a></li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-search"></i> <span>Reports</span>
                            <span class="pull-right-container">
                                <i class="fa fa-angle-left pull-right"></i>
                            </span>
                        </a>
                        <ul class="treeview-menu active">
                            <li><a href="ssearch.php">Search Student</a></li>
                            <li><a href="scourse.php">Search Course</a></li>
                            <li><a href="ssubscribe.php">Student Course Registration</a></li>
                        </ul>
                    </li>
                </ul>
                <!-- /.sidebar-menu -->
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h6 style="color:#ccc">
                    Student Course Registration System:
                    <small></small>
                </h6>
            </section>
            <!-- Main content -->
            <section class="content container-fluid">
                <div class="row content">
                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title">Students Course Register Report: </h3>
                            <div class="box-tools pull-right">
                            </div><!-- /.box-tools -->
                        </div><!-- /.box-header -->
                        <div class="box-body">
                            <!-- /.card-header -->
                            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                                <div class="col-sm-12">
                                    <table id="ssubscribeID" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="example1_info">
                                        <thead>
                                            <tr role="row">
                                                <th class="sorting" tabindex="0" aria-controls="ssubscribeID" rowspan="1" colspan="1" style="width: 50%;">Student Name</th>
                                                <th class="sorting" tabindex="1" aria-controls="ssubscribeID" rowspan="1" colspan="1" style="width: 50%;">Course Name</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbodyDataID">
                                        <?php
                                            $str = "";
                                            while($regdata = mysqli_fetch_array($regdtls)){ 
                                            if($regdata['subid'] %2 ==0){
                                                $str = "<tr role='row' class='even'>";
                                            }else{
                                                $str = "<tr role='row' class='odd'>";
                                            }
                                            $str = $str. '<td class="sorting_1">'.$regdata['stdFname'].'</td>';                                            
                                            $str = $str. '<td class="sorting_1">'.$regdata['cname'].'</td>';                                           
                                            echo $str;
                                        }
                                        ?>
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th rowspan="1" colspan="1">Student Name</th>
                                                <th rowspan="1" colspan="1">Course Name</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
			</section>
			 </div>
    <!-- /.content-wrapper -->
    <!-- Main Footer -->
    <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
            version : 1.0.0
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2021 <a href="#">Student Information System.</a></strong> All rights reserved.
    </footer>


    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
    immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->
    <!-- REQUIRED JS SCRIPTS -->
    <!-- jQuery 3 -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/system.js"></script>
    <!-- page script -->
    <script>
		try{  
			$(document).ready(function() {
				$('#ssubscribeID').DataTable()
			})
		}catch(e){  
			alert("Error:::"+e.message); 
			location.href = "http://localhost/final/index.html";
		}  
    </script>
</body>
</html>